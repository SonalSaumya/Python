import pandas as pd

df= pd.read_csv("sales.csv")

print(df.head(10))

df.isna().sum()

df.ffill()

print(df)


df['Date'] = pd.to_datetime(['Date'])
print(df)

tdf =df.groupby("Store")["Sales"].sum()
tdf.sort_values(ascending=False)

df.drop_duplicates()
print(df)


Q1 = df['Sales'].quantile(0.25)
Q3 = df['Sales'].quantile(0.75)

IQR = Q3 - Q1

lb= Q1-1.5*IQR
ub=Q3+1.5-IQR


outliers = df[(df['Sales'] < lb) | (df['Sales'] > ub) ]

median = df['sales'].median()

